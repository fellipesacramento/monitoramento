# Categorias

Definição das categorias.