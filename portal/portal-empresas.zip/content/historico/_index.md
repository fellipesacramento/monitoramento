# Histórico

Registro append-only.