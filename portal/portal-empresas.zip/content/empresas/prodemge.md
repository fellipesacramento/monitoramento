---
nome: "PRODEMGE"
categoria: "C1"
afinidade: "alta"
afinidade_emoji: "🟢"
status: "alvo"
status_emoji: "🎯"
---

# PRODEMGE

Empresa pública de TI.